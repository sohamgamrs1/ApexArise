# ApexArise - System Player
Tagline: Level Up Your Real Life - The System Has Chosen You.
Package: com.apexarise.system.player

Clone of Solo X Player with original branding.

## Setup
1. flutter pub get
2. dart run build_runner build --delete-conflicting-outputs
3. Add google-services.json to android/app/
4. flutter run (real device required for UsageStats + Overlay)

## Features Implemented
- Onboarding Warrior Init
- Name Input
- Calibration (BMI, body type, goal)
- System Access Permission storytelling + real UsageStatsManager
- Threat Detection 7-day analysis + bar chart
- Smart Block explanation
- Dark Lock permission + overlay blocking
- Breathing Quest
- Commitment chips
- Signup (Google)
- Path Ready timeline
- Home SystemX (streak calendar, XP, tasks with STR/INT/AGI tags)
- Dark Lock Main (Boss Arena, daily limits, smart open 5m + cooldown 15m)
- Rank E- to S evaluation
- Focus Gate Pomodoro Dungeon

## Permissions
PACKAGE_USAGE_STATS, SYSTEM_ALERT_WINDOW, QUERY_ALL_PACKAGES, FOREGROUND_SERVICE

## Architecture
Riverpod + Hive offline first + Firebase sync + MethodChannel for UsageStats
