import 'package:hive/hive.dart';
part 'quest_model.g.dart';

@HiveType(typeId: 1)
class QuestModel extends HiveObject {
  @HiveField(0) String id;
  @HiveField(1) String title;
  @HiveField(2) int xp;
  @HiveField(3) String statTag; // STR, INT, AGI, WIT, VIT
  @HiveField(4) bool completed;
  @HiveField(5) DateTime? scheduledDate;
  @HiveField(6) String difficulty; // E-, E, E+, D etc

  QuestModel({
    required this.id,
    required this.title,
    this.xp = 10,
    this.statTag = "STR",
    this.completed = false,
    this.scheduledDate,
    this.difficulty = "E",
  });
}

@HiveType(typeId: 2)
class BlockModel extends HiveObject {
  @HiveField(0) String packageName;
  @HiveField(1) int dailyLimitMinutes;
  @HiveField(2) bool isBlocked;
  @HiveField(3) int todayUsedMinutes;
  @HiveField(4) DateTime? cooldownUntil;

  BlockModel({
    required this.packageName,
    this.dailyLimitMinutes = 30,
    this.isBlocked = false,
    this.todayUsedMinutes = 0,
  });
}
