import 'package:hive/hive.dart';
part 'player_model.g.dart';

@HiveType(typeId: 0)
class PlayerModel extends HiveObject {
  @HiveField(0) String name;
  @HiveField(1) double height;
  @HiveField(2) double weight;
  @HiveField(3) String bodyType;
  @HiveField(4) String goal;
  @HiveField(5) int xp;
  @HiveField(6) int level;
  @HiveField(7) String rank;
  @HiveField(8) int streak;
  @HiveField(9) List<String> commitments;
  @HiveField(10) DateTime createdAt;
  @HiveField(11) String avatarPath;

  PlayerModel({
    required this.name,
    this.height = 170,
    this.weight = 65,
    this.bodyType = "Normal",
    this.goal = "Muscular",
    this.xp = 0,
    this.level = 1,
    this.rank = "E-",
    this.streak = 1,
    this.commitments = const [],
    required this.createdAt,
    this.avatarPath = "",
  });

  double get bmi => weight / ((height/100)*(height/100));
  String get bmiLabel {
    if (bmi < 18.5) return "Underweight";
    if (bmi < 24.9) return "Normal";
    if (bmi < 29.9) return "Good Muscle";
    if (bmi < 34.9) return "Overweight";
    return "Obese";
  }

  int get xpToNext => 500 - (xp % 500);
}
