import 'package:flutter/material.dart';
import 'screens/onboarding/warrior_init_screen.dart';
import 'core/theme.dart';

class ApexAriseApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ApexArise',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: WarriorInitScreen(),
    );
  }
}
