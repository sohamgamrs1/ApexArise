class Lore {
  static const myLiege = "My Liege";
  static const system = "SYSTEM";
  static const threatDetected = "Threat Detected";
  static const bossDetected = "Boss App Detected";
  static const ranks = ["E-", "E", "E+", "D-", "D", "D+", "C-", "C", "C+", "B-", "B", "B+", "A-", "A", "A+", "S"];
  static const mascotName = "Apex";
  
  static String greeting(String name) => "It's my greatest honor to serve you $myLiege!";
  static String calibrateBody = "Let me calibrate your body stats, $myLiege.";
  static String calibrateGoal = "What is your goal, $myLiege? Choose your path to greatness.";
}
