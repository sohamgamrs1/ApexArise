import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const bg = Color(0xFF070A12);
  static const cardBg = Color(0xFF121A2B);
  static const cardBorder = Color(0xFF1E2A44);
  static const primary = Color(0xFF3A7DFF);
  static const primary2 = Color(0xFF4F46E5);
  static const cyan = Color(0xFF00E5FF);
  static const white = Color(0xFFFFFFFF);
  static const textSec = Color(0xFF8B95B0);
  static const danger = Color(0xFFFF3B3B);
  static const success = Color(0xFF00E676);
}

class AppTheme {
  static ThemeData dark = ThemeData(
    scaffoldBackgroundColor: AppColors.bg,
    useMaterial3: true,
    colorScheme: ColorScheme.dark(
      primary: AppColors.primary,
      background: AppColors.bg,
      surface: AppColors.cardBg,
    ),
    textTheme: GoogleFonts.manropeTextTheme(ThemeData.dark().textTheme),
  );

  static TextStyle headingLarge = GoogleFonts.spaceGrotesk(
    fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.white, letterSpacing: -0.8, height: 1.1,
  );
  static TextStyle headingMedium = GoogleFonts.spaceGrotesk(
    fontSize: 24, fontWeight: FontWeight.w700, color: AppColors.white, letterSpacing: -0.5,
  );
  static TextStyle body = GoogleFonts.manrope(
    fontSize: 15, fontWeight: FontWeight.w400, color: AppColors.white, height: 1.5,
  );
  static TextStyle bodySec = GoogleFonts.manrope(
    fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textSec, height: 1.5,
  );
  static TextStyle systemTag = GoogleFonts.spaceGrotesk(
    fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 3, color: AppColors.primary,
  );
  static TextStyle orbitronBig = GoogleFonts.orbitron(
    fontSize: 56, fontWeight: FontWeight.w900, color: AppColors.white, letterSpacing: 2,
  );
}
