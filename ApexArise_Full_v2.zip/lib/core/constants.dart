class Constants {
  static const appName = "ApexArise";
  static const packageName = "com.apexarise.system.player";
  static const tagline = "Level Up Your Real Life - The System Has Chosen You.";
  static const hiveBoxPlayer = "player_box";
  static const hiveBoxBlocks = "blocks_box";
  static const hiveBoxQuests = "quests_box";
}
