import 'package:flutter/material.dart';
import '../core/theme.dart';

class SystemCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final Color? borderColor;
  SystemCard({required this.child, this.padding, this.borderColor});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? AppColors.cardBorder, width: 1),
      ),
      child: child,
    );
  }
}
