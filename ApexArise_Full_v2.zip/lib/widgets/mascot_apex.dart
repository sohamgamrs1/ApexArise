import 'package:flutter/material.dart';
import '../core/theme.dart';

class MascotApex extends StatefulWidget {
  final double size;
  final String? speech;
  MascotApex({this.size = 120, this.speech});
  @override State<MascotApex> createState() => _MascotApexState();
}

class _MascotApexState extends State<MascotApex> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _float;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: Duration(milliseconds: 2000))..repeat(reverse: true);
    _float = Tween<double>(begin: -6, end: 6).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _float,
          builder: (_, child) => Transform.translate(offset: Offset(0, _float.value), child: child),
          child: CustomPaint(size: Size(widget.size, widget.size), painter: ApexPainter()),
        ),
        if (widget.speech != null) ...[
          SizedBox(height: 12),
          Container(
            constraints: BoxConstraints(maxWidth: 260),
            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: AppColors.cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: Text(widget.speech!, style: TextStyle(color: Colors.white, fontSize: 13), textAlign: TextAlign.center),
          ),
        ]
      ],
    );
  }
}

class ApexPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width/2, size.height/2);
    final bodyPaint = Paint()..color = Color(0xFF1A233A)..style = PaintingStyle.fill;
    final armorPaint = Paint()..color = Color(0xFF121A2B)..style = PaintingStyle.fill;
    final glowPaint = Paint()..color = AppColors.cyan..maskFilter = MaskFilter.blur(BlurStyle.normal, 12);
    final eyePaint = Paint()..color = AppColors.cyan;
    // Helmet
    final helmetRect = RRect.fromRectAndRadius(Rect.fromCenter(center: center, width: size.width*0.8, height: size.height*0.75), Radius.circular(22));
    canvas.drawRRect(helmetRect, armorPaint);
    canvas.drawRRect(helmetRect, Paint()..color = AppColors.cardBorder..style = PaintingStyle.stroke..strokeWidth = 1.5);
    // Eyes
    canvas.drawCircle(Offset(center.dx - 14, center.dy - 5), 10, glowPaint);
    canvas.drawCircle(Offset(center.dx + 14, center.dy - 5), 10, glowPaint);
    canvas.drawCircle(Offset(center.dx - 14, center.dy - 5), 6, eyePaint);
    canvas.drawCircle(Offset(center.dx + 14, center.dy - 5), 6, eyePaint);
    // Mouth slit
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(center.dx, center.dy+14), width: 22, height: 4), Radius.circular(2)), Paint()..color = AppColors.textSec.withOpacity(0.6));
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
