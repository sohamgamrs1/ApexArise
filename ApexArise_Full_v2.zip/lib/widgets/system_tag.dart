import 'package:flutter/material.dart';
import '../core/theme.dart';

class SystemTag extends StatelessWidget {
  final String text;
  SystemTag({this.text = "SYSTEM"});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 6,height: 6,decoration: BoxDecoration(color: AppColors.primary, shape: BoxShape.circle, boxShadow: [BoxShadow(color: AppColors.primary, blurRadius: 6)])),
        SizedBox(width: 8),
        Text("● $text", style: AppTheme.systemTag),
      ],
    );
  }
}
