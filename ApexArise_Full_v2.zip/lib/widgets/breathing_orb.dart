import 'package:flutter/material.dart';
import '../core/theme.dart';

class BreathingOrb extends StatefulWidget {
  final VoidCallback? onCycleComplete;
  BreathingOrb({this.onCycleComplete});
  @override State<BreathingOrb> createState() => _BreathingOrbState();
}

class _BreathingOrbState extends State<BreathingOrb> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  String phase = "Breathe In";
  int cycles = 0;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: Duration(seconds: 10))..repeat();
    _c.addListener(() {
      final v = _c.value;
      String newPhase;
      if (v < 0.4) newPhase = "Breathe In";
      else if (v < 0.6) newPhase = "Hold";
      else newPhase = "Breathe Out";
      if (newPhase != phase) setState(()=>phase = newPhase);
      if (v > 0.99) {
        cycles++;
        if (cycles >= 1) widget.onCycleComplete?.call();
      }
    });
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final scale = 0.8 + 0.4 * (_c.value < 0.5 ? _c.value*2 : (1-_c.value)*2);
        return Column(
          children: [
            Container(
              width: 180*scale,
              height: 180*scale,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [AppColors.primary.withOpacity(0.8), AppColors.primary2.withOpacity(0.3)]),
                boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.6), blurRadius: 40, spreadRadius: 10)],
              ),
              child: Center(child: Text(phase, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
            ),
            SizedBox(height: 16),
            Text("Follow the circle - expand as you inhale, settle as you exhale.", style: TextStyle(color: AppColors.textSec, fontSize: 12), textAlign: TextAlign.center),
          ],
        );
      },
    );
  }
}
