import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'package:google_fonts/google_fonts.dart';

class GlowButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final bool enabled;
  final IconData? icon;
  GlowButton({required this.text, required this.onTap, this.enabled = true, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: enabled ? [BoxShadow(color: AppColors.primary.withOpacity(0.5), blurRadius: 24, spreadRadius: 1)] : [],
      ),
      child: ElevatedButton(
        onPressed: enabled ? onTap : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: enabled ? AppColors.primary : AppColors.cardBg,
          disabledBackgroundColor: AppColors.cardBg,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          padding: EdgeInsets.symmetric(horizontal: 28, vertical: 18),
          elevation: 0,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[Icon(icon, size: 18), SizedBox(width: 8)],
            Text(text, style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700, fontSize: 16, letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}

class SecondaryButton extends StatelessWidget {
  final String text; final VoidCallback onTap;
  SecondaryButton({required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onTap,
      child: Text(text, style: TextStyle(color: AppColors.textSec)),
    );
  }
}
