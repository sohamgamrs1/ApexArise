import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/usage_service.dart';

final weeklyStatsProvider = FutureProvider<Map<String,int>>((ref) async {
  return await UsageService.getWeeklyStats();
});

final threatLevelProvider = Provider<int>((ref) {
  final asyncStats = ref.watch(weeklyStatsProvider);
  return asyncStats.when(
    data: (stats) {
      final avg = UsageService.dailyAvg(stats);
      return (avg/60).clamp(1, 10).round();
    },
    loading: () => 5,
    error: (_,__) => 9,
  );
});
