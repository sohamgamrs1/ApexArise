import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/player_model.dart';
import '../core/constants.dart';

final playerBoxProvider = Provider<Box<PlayerModel>>((ref) => Hive.box<PlayerModel>(Constants.hiveBoxPlayer));

final playerProvider = StateNotifierProvider<PlayerNotifier, PlayerModel?>((ref) {
  final box = ref.watch(playerBoxProvider);
  return PlayerNotifier(box);
});

class PlayerNotifier extends StateNotifier<PlayerModel?> {
  final Box<PlayerModel> box;
  PlayerNotifier(this.box) : super(box.values.firstOrNull);

  void createPlayer(String name, double height, double weight, String bodyType, String goal, List<String> commitments) {
    final player = PlayerModel(
      name: name,
      height: height,
      weight: weight,
      bodyType: bodyType,
      goal: goal,
      commitments: commitments,
      createdAt: DateTime.now(),
      xp: 30,
      streak: 1,
      rank: "E-",
    );
    box.add(player);
    state = player;
  }

  void addXp(int xp) {
    if (state == null) return;
    state!.xp += xp;
    state!.save();
    state = state;
  }

  void updateStreak() {
    if (state == null) return;
    state!.streak += 1;
    state!.save();
    state = state;
  }
}
