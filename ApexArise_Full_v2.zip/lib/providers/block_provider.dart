import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/quest_model.dart';
import '../core/constants.dart';

final blockBoxProvider = Provider<Box<BlockModel>>((ref) => Hive.box<BlockModel>(Constants.hiveBoxBlocks));

final blockedAppsProvider = StateProvider<List<BlockModel>>((ref) {
  final box = ref.watch(blockBoxProvider);
  return box.values.toList();
});

final blockLimitProvider = StateProvider<Map<String,int>>((ref) => {});
