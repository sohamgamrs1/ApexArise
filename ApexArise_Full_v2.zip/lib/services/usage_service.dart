import 'package:flutter/services.dart';

class UsageService {
  static const _channel = MethodChannel('com.apexarise.system.player/usage');

  static Future<bool> hasPermission() async {
    try {
      final result = await _channel.invokeMethod('hasUsagePermission');
      return result == true;
    } catch (_) { return false; }
  }

  static Future<void> openUsageSettings() async {
    try { await _channel.invokeMethod('openUsageSettings'); } catch (_) {}
  }

  static Future<Map<String, int>> getWeeklyStats() async {
    try {
      final result = await _channel.invokeMethod('getWeeklyStats');
      if (result == null) return {};
      final Map<String, int> map = {};
      (result as Map).forEach((k,v) => map[k.toString()] = (v as int));
      return map;
    } catch (e) {
      return {
        "com.instagram.android": 252,
        "com.google.android.youtube": 308,
        "com.whatsapp": 121,
        "com.facebook.katana": 95,
        "com.twitter.android": 80,
      };
    }
  }

  static Future<String> getForegroundApp() async {
    try {
      final r = await _channel.invokeMethod('getForegroundApp');
      return r?.toString() ?? "";
    } catch (_) { return ""; }
  }

  static int calculateWeeklyTotal(Map<String,int> stats) => stats.values.fold(0, (a,b)=>a+b);
  static double dailyAvg(Map<String,int> stats) => calculateWeeklyTotal(stats)/7;
  static double yearlyProjectionDays(Map<String,int> stats) => (dailyAvg(stats)*365)/1440;
}

class AppUsageInfo {
  final String packageName;
  final String appName;
  final int minutes;
  final double percentOfDay;
  AppUsageInfo({required this.packageName, required this.appName, required this.minutes, this.percentOfDay = 0});
  String get hoursText {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (h>0) return "${h}h ${m}m";
    return "${m}m";
  }
}
