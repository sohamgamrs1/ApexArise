import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/quest_model.dart';
import '../core/constants.dart';
import 'dart:async';

class BlockService {
  static const smartOpen = Duration(minutes: 5);
  static const cooldown = Duration(minutes: 15);
  static Timer? _monitorTimer;
  static Function(String)? onBlockTriggered;

  static Box<BlockModel> get box => Hive.box<BlockModel>(Constants.hiveBoxBlocks);

  static Future<void> init() async {
    await requestOverlayPermission();
  }

  static Future<bool> requestOverlayPermission() async {
    final granted = await FlutterOverlayWindow.isPermissionGranted();
    if (!granted) {
      await FlutterOverlayWindow.requestPermission();
      return await FlutterOverlayWindow.isPermissionGranted();
    }
    return true;
  }

  static Future<void> showBlockOverlay(String appName, int limitMinutes) async {
    if (!await FlutterOverlayWindow.isPermissionGranted()) return;
    await FlutterOverlayWindow.showOverlay(
      enableDrag: false,
      overlayTitle: "ApexArise protecting focus",
      overlayText: "Boss $appName defeated",
      flag: OverlayFlag.defaultFlag,
      visibility: NotificationVisibility.visibilityPublic,
      positionGravity: PositionGravity.auto,
      height: 2000,
      width: 2000,
    );
  }

  static Future<void> closeOverlay() async {
    try { await FlutterOverlayWindow.closeOverlay(); } catch (_) {}
  }

  static void setDailyLimit(String packageName, int minutes) {
    final existing = box.values.where((b)=>b.packageName==packageName).firstOrNull;
    if (existing != null) {
      existing.dailyLimitMinutes = minutes;
      existing.save();
    } else {
      box.add(BlockModel(packageName: packageName, dailyLimitMinutes: minutes, isBlocked: true));
    }
  }

  static void startMonitoring(Function(String) onBlock) {
    onBlockTriggered = onBlock;
    _monitorTimer?.cancel();
    _monitorTimer = Timer.periodic(Duration(seconds: 5), (t) async {
      // Check foreground app vs limits - implemented via UsageService in real app
    });
  }

  static void stopMonitoring() => _monitorTimer?.cancel();
}
