import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import '../core/theme.dart';
import '../widgets/mascot_apex.dart';

class OverlayBlockScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bg,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.bg,
          border: Border.all(color: AppColors.danger.withOpacity(0.3), width: 2),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shield, size: 80, color: AppColors.danger),
            SizedBox(height: 20),
            Text("BOSS DEFEATED!", style: AppTheme.headingLarge.copyWith(color: AppColors.danger)),
            SizedBox(height: 12),
            Text("Threat contained, My Liege.
Come back after cooldown.", textAlign: TextAlign.center, style: AppTheme.body),
            SizedBox(height: 24),
            MascotApex(),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                await FlutterOverlayWindow.closeOverlay();
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
              child: Text("Return to System"),
            ),
          ],
        ),
      ),
    );
  }
}

// Entry point for overlay
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: OverlayBlockScreen()));
}
