import 'package:hive_flutter/hive_flutter.dart';
import '../models/player_model.dart';
import '../models/quest_model.dart';
import '../core/constants.dart';

class HiveService {
  static Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(PlayerModelAdapter());
    Hive.registerAdapter(QuestModelAdapter());
    Hive.registerAdapter(BlockModelAdapter());
    await Hive.openBox<PlayerModel>(Constants.hiveBoxPlayer);
    await Hive.openBox<BlockModel>(Constants.hiveBoxBlocks);
    await Hive.openBox<QuestModel>(Constants.hiveBoxQuests);
  }

  static Box<PlayerModel> get playerBox => Hive.box<PlayerModel>(Constants.hiveBoxPlayer);
  static Box<BlockModel> get blockBox => Hive.box<BlockModel>(Constants.hiveBoxBlocks);
  static Box<QuestModel> get questBox => Hive.box<QuestModel>(Constants.hiveBoxQuests);
}
