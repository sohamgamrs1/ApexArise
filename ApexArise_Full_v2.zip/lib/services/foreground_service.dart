import 'dart:async';
import 'package:flutter/services.dart';
import 'usage_service.dart';
import 'block_service.dart';

class ForegroundMonitor {
  static Timer? _timer;
  static const _channel = MethodChannel('com.apexarise.system.player/usage');

  static void start() {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 5), (t) async {
      final fg = await UsageService.getForegroundApp();
      final stats = await UsageService.getWeeklyStats();
      final used = stats[fg] ?? 0;
      final box = BlockService.box;
      final blocked = box.values.where((b)=>b.packageName==fg && b.isBlocked).firstOrNull;
      if (blocked != null && used >= blocked.dailyLimitMinutes) {
        final cooldown = blocked.cooldownUntil;
        if (cooldown == null || cooldown.isBefore(DateTime.now())) {
          await BlockService.showBlockOverlay(fg, blocked.dailyLimitMinutes);
          blocked.cooldownUntil = DateTime.now().add(BlockService.cooldown);
          blocked.save();
          BlockService.onBlockTriggered?.call(fg);
        }
      }
    });
  }

  static void stop() => _timer?.cancel();
}
