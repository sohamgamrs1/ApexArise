import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'services/hive_service.dart';
import 'services/block_service.dart';
import 'app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await HiveService.init();
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // Firebase optional for offline first
  }
  await BlockService.init();
  runApp(ProviderScope(child: ApexAriseApp()));
}
