import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/system_card.dart';
import '../../widgets/glow_button.dart';
import '../auth/signup_screen.dart';

class CommitmentScreen extends StatefulWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  final Map<String,int> stats;
  CommitmentScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal, required this.stats});
  @override State<CommitmentScreen> createState() => _CommitmentScreenState();
}

class _CommitmentScreenState extends State<CommitmentScreen> {
  List<String> selected = [];

  final options = [
    "Take control of my life - I'm tired of drifting. I want to lead my own day.",
    "Stop wasting time",
    "Build real confidence",
    "Prove something to myself",
    "Become unstoppable",
    "Identity Shift",
    "Focus Recovery",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "COMMITMENT PROTOCOL"),
              SizedBox(height: 16),
              Text("Why This Matters", style: AppTheme.headingMedium),
              Text("Feel how the system rewards small wins.", style: AppTheme.bodySec),
              SizedBox(height: 8),
              Text("When your reason is clear, your discipline gets stronger.", style: AppTheme.body),
              SizedBox(height: 8),
              Text("Pick what hits deepest - Choose one or more", style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w600)),
              SizedBox(height: 20),
              Wrap(spacing: 8, runSpacing: 8, children: options.map((o){
                final sel = selected.contains(o);
                return ChoiceChip(
                  label: Text(o),
                  selected: sel,
                  onSelected: (v){
                    setState((){
                      if (v) selected.add(o); else selected.remove(o);
                    });
                  },
                  selectedColor: AppColors.primary,
                  backgroundColor: AppColors.cardBg,
                  labelStyle: TextStyle(color: sel ? Colors.white : AppColors.textSec, fontSize: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: sel ? AppColors.primary : AppColors.cardBorder)),
                );
              }).toList()),
              Spacer(),
              GlowButton(text: "Lock My Commitment", onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => SignupScreen(
                  hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal, stats: widget.stats, commitments: selected,
                )));
              }),
              SizedBox(height: 12),
              Center(child: TextButton(onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => SignupScreen(
                  hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal, stats: widget.stats, commitments: selected,
                )));
              }, child: Text("Skip for now", style: TextStyle(color: AppColors.textSec)))),
            ],
          ),
        ),
      ),
    );
  }
}
