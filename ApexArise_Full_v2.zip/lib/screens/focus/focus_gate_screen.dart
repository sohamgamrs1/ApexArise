import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/glow_button.dart';
import 'focus_gate_running_screen.dart';

class FocusGateScreen extends StatefulWidget {
  @override State<FocusGateScreen> createState() => _FocusGateScreenState();
}

class _FocusGateScreenState extends State<FocusGateScreen> {
  int selectedMinutes = 25;

  @override
  Widget build(BuildContext context) {
    final endTime = DateTime.now().add(Duration(minutes: selectedMinutes));
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(backgroundColor: AppColors.bg, title: Text("Focus Gate", style: TextStyle(color: Colors.white)), iconTheme: IconThemeData(color: Colors.white)),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SystemTag(text: "GATE PROTOCOL"),
            SizedBox(height: 12),
            Text("Focus Gate - Clear a gate today to start a streak.", style: AppTheme.headingMedium),
            SizedBox(height: 20),
            Row(children: [
              _timeChip("E- 15min", 15),
              SizedBox(width: 8),
              _timeChip("E 25min", 25),
              SizedBox(width: 8),
              _timeChip("E+ 55min", 55),
            ]),
            SizedBox(height: 20),
            SystemCard(
              borderColor: AppColors.primary.withOpacity(0.4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("$selectedMinutes Minutes - ends ${TimeOfDay.fromDateTime(endTime).format(context)}", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  SizedBox(height: 12),
                  _gateOption("Section PRO", true),
                  _gateOption("Block boss apps PRO", true),
                  _gateOption("No escape mid-run", false),
                  _gateOption("Rest days 2 left", false),
                ],
              ),
            ),
            Spacer(),
            GlowButton(text: "Enter gate: $selectedMinutes min", onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (_) => FocusGateRunningScreen(minutes: selectedMinutes)));
            }),
          ],
        ),
      ),
    );
  }

  Widget _timeChip(String label, int mins) {
    final sel = selectedMinutes==mins;
    return ChoiceChip(label: Text(label), selected: sel, onSelected: (_)=>setState(()=>selectedMinutes=mins), selectedColor: AppColors.primary, backgroundColor: AppColors.cardBg, labelStyle: TextStyle(color: sel ? Colors.white : AppColors.textSec));
  }

  Widget _gateOption(String label, bool pro) => Padding(
    padding: EdgeInsets.only(bottom: 8),
    child: Row(children: [
      Icon(pro ? Icons.lock : Icons.check_circle, size: 16, color: pro ? AppColors.textSec : AppColors.success),
      SizedBox(width: 8),
      Text(label, style: TextStyle(color: pro ? AppColors.textSec : Colors.white, fontSize: 13)),
      if (pro) ...[SizedBox(width: 6), Container(padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.2), borderRadius: BorderRadius.circular(4)), child: Text("PRO", style: TextStyle(color: AppColors.primary, fontSize: 9)))],
    ]),
  );
}
