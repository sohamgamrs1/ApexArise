import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/mascot_apex.dart';
import 'dart:async';

class FocusGateRunningScreen extends StatefulWidget {
  final int minutes;
  FocusGateRunningScreen({required this.minutes});
  @override State<FocusGateRunningScreen> createState() => _FocusGateRunningScreenState();
}

class _FocusGateRunningScreenState extends State<FocusGateRunningScreen> {
  late int secondsLeft;
  Timer? timer;
  bool paused = false;

  @override
  void initState() {
    super.initState();
    secondsLeft = widget.minutes * 60;
    timer = Timer.periodic(Duration(seconds: 1), (t){
      if (!paused && secondsLeft>0) setState(()=>secondsLeft--);
    });
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  String get timeStr {
    final m = (secondsLeft~/60).toString().padLeft(2,'0');
    final s = (secondsLeft%60).toString().padLeft(2,'0');
    return "$m:$s";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 20),
            Text("Gate stable", style: TextStyle(color: AppColors.success)),
            Text("+0 XP", style: TextStyle(color: AppColors.textSec)),
            Spacer(),
            Text(timeStr, style: TextStyle(color: Colors.white, fontSize: 72, fontWeight: FontWeight.w900, letterSpacing: 2)),
            SizedBox(height: 20),
            MascotApex(size: 100),
            SizedBox(height: 12),
            Text("Scouting the gate... Next enemy in 01:30", style: TextStyle(color: AppColors.textSec, fontSize: 12)),
            Spacer(),
            Padding(
              padding: EdgeInsets.all(24),
              child: Row(
                children: [
                  Expanded(child: OutlinedButton(onPressed: ()=>setState(()=>paused=!paused), style: OutlinedButton.styleFrom(side: BorderSide(color: AppColors.cardBorder)), child: Text(paused ? "Resume" : "Pause", style: TextStyle(color: Colors.white)))),
                  SizedBox(width: 12),
                  Expanded(child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.cardBg), onPressed: (){
                    showDialog(context: context, builder: (_) => AlertDialog(
                      backgroundColor: AppColors.cardBg,
                      title: Text("Leave the gate?", style: TextStyle(color: Colors.white)),
                      content: Text("You've only just started... You will lose:\n• The +${widget.minutes} XP clear reward\n• Today's streak credit\n• Loot still waiting in this gate", style: TextStyle(color: AppColors.textSec)),
                      actions: [
                        TextButton(onPressed: ()=>Navigator.pop(context), child: Text("Stay in the gate", style: TextStyle(color: AppColors.primary))),
                        TextButton(onPressed: (){ Navigator.pop(context); setState(()=>paused=true); }, child: Text("Pause instead")),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
                          onPressed: (){
                            Navigator.pop(context);
                            Navigator.pop(context);
                          },
                          child: Text("Press and hold to retreat"),
                        ),
                      ],
                    ));
                  }, child: Text("Retreat", style: TextStyle(color: AppColors.danger)))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
