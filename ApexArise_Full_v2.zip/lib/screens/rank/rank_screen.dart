import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/system_tag.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/player_provider.dart';

class RankScreen extends ConsumerStatefulWidget {
  @override ConsumerState<RankScreen> createState() => _RankScreenState();
}

class _RankScreenState extends ConsumerState<RankScreen> {
  bool evaluating = false;
  List<String> logs = [];
  final evalSteps = [
    "HUNTER DETECTED",
    "READING COMBAT RECORD...",
    "ANALYZING REGISTERED HUNTERS...",
    "CROSS-REFERENCING GUILD DATABASE...",
    "CALCULATING THREAT LEVEL...",
    "SYNCHRONIZING WITH SYSTEM...",
  ];

  void startEval() async {
    setState((){ evaluating=true; logs=[]; });
    for (var s in evalSteps) {
      await Future.delayed(Duration(milliseconds: 600));
      setState(()=>logs.add(s));
    }
    await Future.delayed(Duration(milliseconds: 800));
    setState(()=>evaluating=false);
    if (mounted) {
      showDialog(context: context, builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBg,
        title: Text("Congratulations player you are the E- Ranker in the World!", style: TextStyle(color: Colors.white)),
        content: Text("Need premium System to get accurate rank!", style: TextStyle(color: AppColors.textSec)),
        actions: [
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary), onPressed: ()=>Navigator.pop(context), child: Text("Buy Premium #1XXXX")),
          TextButton(onPressed: ()=>Navigator.pop(context), child: Text("Watch ADs, SOON")),
        ],
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final player = ref.watch(playerProvider);
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(backgroundColor: AppColors.bg, title: Text("Hunter Evaluation", style: TextStyle(color: Colors.white)), iconTheme: IconThemeData(color: Colors.white)),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            SystemTag(text: "RANK PROTOCOL"),
            SizedBox(height: 20),
            SystemCard(
              borderColor: AppColors.primary.withOpacity(0.5),
              child: Column(
                children: [
                  Icon(Icons.emoji_events, size: 80, color: AppColors.primary),
                  SizedBox(height: 12),
                  Text("E- HUNTER EVALUATION", style: AppTheme.headingMedium),
                  SizedBox(height: 8),
                  Text(player?.name ?? "Heroo", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                  SizedBox(height: 8),
                  Text("XP ${player?.xp ?? 30}/500", style: TextStyle(color: AppColors.cyan)),
                  SizedBox(height: 8),
                  LinearProgressIndicator(value: 0.06, backgroundColor: AppColors.bg, valueColor: AlwaysStoppedAnimation(AppColors.primary)),
                  SizedBox(height: 8),
                  Text("${player?.xpToNext ?? 470} XP to E", style: TextStyle(color: AppColors.textSec, fontSize: 12)),
                  SizedBox(height: 12),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    _badge("Common", "The Beginning ???"),
                    SizedBox(width: 8),
                    _badge("1/12", "unlocked"),
                  ]),
                ],
              ),
            ),
            SizedBox(height: 20),
            if (evaluating) ...[
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: logs.map((l) => Padding(padding: EdgeInsets.only(bottom: 6), child: Row(children: [SizedBox(width: 12,height: 12, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary)), SizedBox(width: 8), Text(l, style: TextStyle(color: AppColors.cyan, fontSize: 12))]))).toList(),
                ),
              ),
            ] else
              GlowButton(text: "TAP TO EVALUATE", onTap: startEval),
            Spacer(),
            Text("Global Rank List", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            SizedBox(height: 12),
            Expanded(child: ListView.builder(itemCount: 5, itemBuilder: (_,i)=>SystemCard(child: Row(children: [CircleAvatar(backgroundColor: AppColors.bg, child: Text("${i+1}")), SizedBox(width: 12), Text("Hunter ${i+1}", style: TextStyle(color: Colors.white)), Spacer(), Text("Lvl ${20-i*2}", style: TextStyle(color: AppColors.textSec))])))),
          ],
        ),
      ),
    );
  }

  Widget _badge(String a, String b) => Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.cardBorder)), child: Column(children: [Text(a, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)), Text(b, style: TextStyle(color: AppColors.textSec, fontSize: 10))]));
}
