import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/glow_button.dart';
import '../dark_lock/dark_lock_permission_screen.dart';

class SmartBlockExplainScreen extends StatelessWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  final Map<String,int> stats;
  SmartBlockExplainScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal, required this.stats});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "SMART BLOCK PROTOCOL"),
              SizedBox(height: 20),
              Text("The Problem with Other Blockers", style: AppTheme.headingMedium),
              SizedBox(height: 16),
              SystemCard(
                borderColor: AppColors.danger.withOpacity(0.3),
                child: Column(
                  children: [
                    _problemRow("Hard Block", "App locked until you unblock manually.", "You break and turn it off anyway", false),
                    Divider(color: AppColors.cardBorder),
                    _problemRow("No 5-min open", "45 min later, still scrolling", "", false),
                  ],
                ),
              ),
              SizedBox(height: 16),
              SystemCard(
                borderColor: AppColors.cyan.withOpacity(0.4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [Icon(Icons.bolt, color: AppColors.cyan), SizedBox(width: 8), Text("Smart Block", style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w800))]),
                    SizedBox(height: 8),
                    Text("Beats doomscrolling without willpower. You set a short window. The app satisfies your craving. Then it locks automatically.", style: AppTheme.body),
                    SizedBox(height: 12),
                    _bullet("You choose how long"),
                    _bullet("Auto-locks when time's up"),
                    _bullet("Reopens after cool-down"),
                  ],
                ),
              ),
              SizedBox(height: 24),
              GlowButton(text: "Activate Smart Block", onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => DarkLockPermissionScreen(
                  hunterName: hunterName, height: height, weight: weight, bodyType: bodyType, goal: goal, stats: stats,
                )));
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _problemRow(String title, String desc, String fail, bool good) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(good ? Icons.check_circle : Icons.cancel, color: good ? AppColors.success : AppColors.danger, size: 20),
        SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          Text(desc, style: AppTheme.bodySec.copyWith(fontSize: 12)),
          if (fail.isNotEmpty) Text("X $fail", style: TextStyle(color: AppColors.danger, fontSize: 11)),
        ])),
      ],
    );
  }

  Widget _bullet(String t) => Padding(
    padding: EdgeInsets.only(bottom: 6),
    child: Row(children: [Container(width: 6,height: 6,decoration: BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle)), SizedBox(width: 8), Text(t, style: TextStyle(color: Colors.white))]),
  );
}
