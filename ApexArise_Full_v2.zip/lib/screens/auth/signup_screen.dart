import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/system_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/mascot_apex.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/player_provider.dart';
import '../path/path_ready_screen.dart';

class SignupScreen extends ConsumerWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  final Map<String,int> stats;
  final List<String> commitments;
  SignupScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal, required this.stats, required this.commitments});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              SystemTag(text: "PLAYER REGISTRATION"),
              SizedBox(height: 20),
              Text("Player Registration - Sign Up", style: AppTheme.headingMedium),
              SizedBox(height: 12),
              MascotApex(size: 90, speech: "My Liege! May I have the honor of knowing your name, Sign up to save your progress when you change devices so that your ranks and achievements will be known!"),
              SizedBox(height: 24),
              SystemCard(
                child: Column(
                  children: [
                    TextField(
                      controller: TextEditingController(text: hunterName),
                      style: TextStyle(color: Colors.white),
                      decoration: InputDecoration(hintText: "Enter the name", hintStyle: TextStyle(color: AppColors.textSec), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
                    ),
                    SizedBox(height: 16),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                      _syncItem(Icons.emoji_events, "Ranks synced"),
                      _syncItem(Icons.local_fire_department, "Streaks saved"),
                      _syncItem(Icons.leaderboard, "Leaderboard"),
                    ]),
                  ],
                ),
              ),
              Spacer(),
              GlowButton(text: "G  Sign Up", icon: Icons.login, onTap: () async {
                ref.read(playerProvider.notifier).createPlayer(hunterName, height, weight, bodyType, goal, commitments);
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => PathReadyScreen(hunterName: hunterName, stats: stats)), (r)=>false);
              }),
              SizedBox(height: 12),
              TextButton(onPressed: () async {
                ref.read(playerProvider.notifier).createPlayer(hunterName, height, weight, bodyType, goal, commitments);
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => PathReadyScreen(hunterName: hunterName, stats: stats)), (r)=>false);
              }, child: Text("No, Thanks", style: TextStyle(color: AppColors.textSec))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _syncItem(IconData icon, String label) => Column(children: [Icon(icon, color: AppColors.primary, size: 20), SizedBox(height: 4), Text(label, style: TextStyle(color: AppColors.textSec, fontSize: 10))]);
}
