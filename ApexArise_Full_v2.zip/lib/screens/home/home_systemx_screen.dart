import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/mascot_apex.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/player_provider.dart';
import '../dark_lock/dark_lock_main_screen.dart';
import '../rank/rank_screen.dart';
import '../focus/focus_gate_screen.dart';
import 'package:intl/intl.dart';

class HomeSystemXScreen extends ConsumerStatefulWidget {
  @override ConsumerState<HomeSystemXScreen> createState() => _HomeSystemXScreenState();
}

class _HomeSystemXScreenState extends ConsumerState<HomeSystemXScreen> {
  int tabIndex = 0;
  int selectedTab = 0; // ALL/HABITS/TODOS

  @override
  Widget build(BuildContext context) {
    final player = ref.watch(playerProvider);
    return Scaffold(
      backgroundColor: AppColors.bg,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.cardBg,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textSec,
        currentIndex: tabIndex,
        onTap: (i){
          if (i==1) Navigator.push(context, MaterialPageRoute(builder: (_)=>DarkLockMainScreen()));
          if (i==2) Navigator.push(context, MaterialPageRoute(builder: (_)=>RankScreen()));
          if (i==3) Navigator.push(context, MaterialPageRoute(builder: (_)=>FocusGateScreen()));
          setState(()=>tabIndex=i);
        },
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: "System"),
          BottomNavigationBarItem(icon: Icon(Icons.shield), label: "Dark Lock"),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: "Rank"),
          BottomNavigationBarItem(icon: Icon(Icons.center_focus_strong), label: "Focus"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Player HQ"),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Streak calendar
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(DateFormat('MMMM yyyy').format(DateTime.now()), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                      SystemTag(text: "STREAK ${player?.streak ?? 1} DAY"),
                    ]),
                    SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(7, (i){
                        final date = DateTime.now().subtract(Duration(days: 6-i));
                        final isToday = i==6;
                        return Container(
                          width: 38,height: 54,
                          decoration: BoxDecoration(color: isToday ? AppColors.primary : AppColors.bg, borderRadius: BorderRadius.circular(10), border: Border.all(color: isToday ? AppColors.primary : AppColors.cardBorder)),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text(DateFormat('E').format(date)[0], style: TextStyle(color: isToday ? Colors.white : AppColors.textSec, fontSize: 10)),
                            Text("${date.day}", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                          ]),
                        );
                      }),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12),
              // Hunter banner
              SystemCard(
                borderColor: AppColors.primary.withOpacity(0.5),
                child: Row(
                  children: [
                    MascotApex(size: 48),
                    SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text("Hunter King crossed Level 20", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                      Text("DAILY BRIEF • Streak 1 day reward +10 XP", style: TextStyle(color: AppColors.textSec, fontSize: 11)),
                    ])),
                    Icon(Icons.chevron_right, color: AppColors.textSec),
                  ],
                ),
              ),
              SizedBox(height: 12),
              // XP Progress
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text("Today's Quest: Push-Ups: 15 (+10 XP)", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      Text("10/500 XP", style: TextStyle(color: AppColors.cyan, fontSize: 12)),
                    ]),
                    SizedBox(height: 8),
                    LinearProgressIndicator(value: 0.02, backgroundColor: AppColors.bg, valueColor: AlwaysStoppedAnimation(AppColors.primary)),
                  ],
                ),
              ),
              SizedBox(height: 12),
              // Tabs ALL/HABITS/TODOS
              Row(children: [
                _tabChip("ALL", 0),
                SizedBox(width: 8),
                _tabChip("HABITS", 1),
                SizedBox(width: 8),
                _tabChip("TODOS", 2),
              ]),
              SizedBox(height: 12),
              // Task list placeholder
              SystemCard(child: Row(children: [
                Checkbox(value: false, onChanged: (_){}, fillColor: MaterialStateProperty.all(AppColors.cardBg)),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("Push-Ups: 15", style: TextStyle(color: Colors.white)),
                  Text("STR • E • +10 XP", style: TextStyle(color: AppColors.textSec, fontSize: 11)),
                ])),
                Icon(Icons.more_horiz, color: AppColors.textSec),
              ])),
              SizedBox(height: 12),
              // Widgets: Health Connect, Measurements, Photo Log, Weekly Strip, Vault
              Text("System Widgets", style: AppTheme.headingMedium.copyWith(fontSize: 16)),
              SizedBox(height: 8),
              Row(children: [
                Expanded(child: SystemCard(child: Column(children: [Icon(Icons.favorite, color: AppColors.primary), SizedBox(height: 6), Text("Health Connect", style: TextStyle(color: Colors.white, fontSize: 11))]))),
                SizedBox(width: 8),
                Expanded(child: SystemCard(child: Column(children: [Icon(Icons.straighten, color: AppColors.cyan), SizedBox(height: 6), Text("Measurements", style: TextStyle(color: Colors.white, fontSize: 11))]))),
                SizedBox(width: 8),
                Expanded(child: SystemCard(child: Column(children: [Icon(Icons.photo, color: AppColors.textSec), SizedBox(height: 6), Text("Photo Log", style: TextStyle(color: Colors.white, fontSize: 11))]))),
              ]),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        onPressed: () => _showCreateTaskSheet(context),
        child: Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _tabChip(String label, int idx) {
    final sel = selectedTab==idx;
    return InkWell(
      onTap: ()=>setState(()=>selectedTab=idx),
      child: Container(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8), decoration: BoxDecoration(color: sel ? AppColors.primary : AppColors.cardBg, borderRadius: BorderRadius.circular(20), border: Border.all(color: sel ? AppColors.primary : AppColors.cardBorder)), child: Text(label, style: TextStyle(color: sel ? Colors.white : AppColors.textSec, fontSize: 12, fontWeight: FontWeight.w700))),
    );
  }

  void _showCreateTaskSheet(BuildContext context) {
    showModalBottomSheet(context: context, backgroundColor: AppColors.cardBg, shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (_){
      return Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Create Quest", style: AppTheme.headingMedium),
            SizedBox(height: 12),
            TextField(decoration: InputDecoration(hintText: "Quest title", hintStyle: TextStyle(color: AppColors.textSec), filled: true, fillColor: AppColors.bg, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
            SizedBox(height: 12),
            Wrap(spacing: 8, children: ["STR","INT","AGI","WIT","VIT"].map((s)=>Chip(label: Text(s), backgroundColor: AppColors.bg, labelStyle: TextStyle(color: AppColors.textSec))).toList()),
            SizedBox(height: 12),
            Row(children: [
              Text("Difficulty & XP", style: TextStyle(color: Colors.white)),
              Spacer(),
              DropdownButton<String>(value: "E", dropdownColor: AppColors.cardBg, items: ["E-","E","E+","D"].map((e)=>DropdownMenuItem(value: e, child: Text(e, style: TextStyle(color: Colors.white)))).toList(), onChanged: (_){}),
            ]),
          ],
        ),
      );
    });
  }
}
