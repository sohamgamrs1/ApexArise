import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../services/usage_service.dart';
import '../../services/block_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class DarkLockMainScreen extends ConsumerStatefulWidget {
  @override ConsumerState<DarkLockMainScreen> createState() => _DarkLockMainScreenState();
}

class _DarkLockMainScreenState extends ConsumerState<DarkLockMainScreen> {
  Map<String,int> stats = {};
  bool loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final s = await UsageService.getWeeklyStats();
    setState((){ stats=s; loading=false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(backgroundColor: AppColors.bg, title: Text("Dark Lock", style: TextStyle(color: Colors.white)), iconTheme: IconThemeData(color: Colors.white)),
      body: loading ? Center(child: CircularProgressIndicator()) :
      SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SystemTag(text: "BOSS ARENA"),
            SizedBox(height: 12),
            SystemCard(
              borderColor: AppColors.danger.withOpacity(0.4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Top Apps Today", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  SizedBox(height: 12),
                  ...stats.entries.take(6).map((e){
                    final blocked = BlockService.box.values.any((b)=>b.packageName==e.key && b.isBlocked);
                    return Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          CircleAvatar(backgroundColor: AppColors.bg, child: Text(e.key.split('.').last[0].toUpperCase())),
                          SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(e.key.split('.').last, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                            Text("${e.value~/60}h ${e.value%60}m today", style: TextStyle(color: AppColors.textSec, fontSize: 12)),
                          ])),
                          Switch(value: blocked, activeColor: AppColors.primary, onChanged: (v){
                            if (v) BlockService.setDailyLimit(e.key, 30);
                            else {
                              final b = BlockService.box.values.where((x)=>x.packageName==e.key).firstOrNull;
                              b?.delete();
                            }
                            setState((){});
                          }),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
            SizedBox(height: 16),
            SystemCard(
              borderColor: AppColors.primary.withOpacity(0.4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Boss Arena: Set daily limit to challenge this boss", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  SizedBox(height: 12),
                  Row(children: [
                    Icon(Icons.timer, color: AppColors.cyan),
                    SizedBox(width: 8),
                    Text("Limit: 30m/day", style: TextStyle(color: AppColors.cyan)),
                    Spacer(),
                    ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary), onPressed: (){}, child: Text("Set")),
                  ]),
                  SizedBox(height: 8),
                  Text("Smart Block: 5min open, then auto-lock, reopen after 15min cooldown", style: TextStyle(color: AppColors.textSec, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
