import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/mascot_apex.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

class OverlayBlockScreenContent extends StatelessWidget {
  final String appName;
  OverlayBlockScreenContent({this.appName = "Boss"});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.bg,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shield_rounded, size: 90, color: AppColors.danger),
            SizedBox(height: 16),
            Text("BOSS DEFEATED!", style: TextStyle(color: AppColors.danger, fontSize: 28, fontWeight: FontWeight.w900)),
            SizedBox(height: 8),
            Text("$appName contained, My Liege.", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            Text("Come back after cooldown - 15m", style: TextStyle(color: AppColors.textSec)),
            SizedBox(height: 24),
            MascotApex(size: 110, speech: "Threat neutralized! You stayed strong, My Liege!"),
            SizedBox(height: 32),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: () async => await FlutterOverlayWindow.closeOverlay(),
              child: Text("Return to System", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
