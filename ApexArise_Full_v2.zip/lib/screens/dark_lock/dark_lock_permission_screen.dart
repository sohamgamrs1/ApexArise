import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/glow_button.dart';
import '../../services/block_service.dart';
import '../breathing/breathing_quest_screen.dart';

class DarkLockPermissionScreen extends StatefulWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  final Map<String,int> stats;
  DarkLockPermissionScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal, required this.stats});
  @override State<DarkLockPermissionScreen> createState() => _DarkLockPermissionScreenState();
}

class _DarkLockPermissionScreenState extends State<DarkLockPermissionScreen> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "DARK LOCK"),
              SizedBox(height: 16),
              Text("Dark Lock - Rather than completely blocking apps, you set a usage limit so you don't overuse and fall into doom scrolling.", style: AppTheme.headingMedium.copyWith(fontSize: 18)),
              SizedBox(height: 16),
              Row(children: [
                ChoiceChip(label: Text("Overlay"), selected: tab==0, onSelected: (_)=>setState(()=>tab=0), selectedColor: AppColors.primary),
                SizedBox(width: 8),
                ChoiceChip(label: Text("Notifications"), selected: tab==1, onSelected: (_)=>setState(()=>tab=1), selectedColor: AppColors.primary),
              ]),
              SizedBox(height: 16),
              Expanded(
                child: ListView.builder(
                  itemCount: widget.stats.length.clamp(0,5),
                  itemBuilder: (context,i){
                    final e = widget.stats.entries.toList()[i];
                    return Padding(
                      padding: EdgeInsets.only(bottom: 10),
                      child: SystemCard(
                        child: Row(
                          children: [
                            CircleAvatar(backgroundColor: AppColors.cardBorder, child: Text(e.key[0].toUpperCase(), style: TextStyle(color: Colors.white))),
                            SizedBox(width: 12),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(e.key.split('.').last, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                              Text("${e.value~/60}h ${e.value%60}m this week", style: AppTheme.bodySec),
                            ])),
                            Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(8)), child: Text("Not Blocked", style: TextStyle(color: AppColors.textSec, fontSize: 11))),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              GlowButton(text: "Continue", onTap: () async {
                // Show warning dialog
                showDialog(context: context, builder: (_) => AlertDialog(
                  backgroundColor: AppColors.cardBg,
                  title: Text("My Liege! I need permission to block...", style: TextStyle(color: Colors.white)),
                  content: Text("Please grant Display over other apps to protect your focus.", style: TextStyle(color: AppColors.textSec)),
                  actions: [
                    TextButton(onPressed: ()=>Navigator.pop(context), child: Text("Later")),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary),
                      onPressed: () async {
                        Navigator.pop(context);
                        await BlockService.requestOverlayPermission();
                        if (context.mounted) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => BreathingQuestScreen(
                            hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal, stats: widget.stats,
                          )));
                        }
                      },
                      child: Text("Grant"),
                    ),
                  ],
                ));
              }),
            ],
          ),
        ),
      ),
    );
  }
}
