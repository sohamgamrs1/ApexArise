import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/mascot_apex.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/system_card.dart';
import '../permissions/system_access_screen.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class CalibrationFlow extends ConsumerStatefulWidget {
  final String hunterName;
  CalibrationFlow({required this.hunterName});
  @override ConsumerState<CalibrationFlow> createState() => _CalibrationFlowState();
}

class _CalibrationFlowState extends ConsumerState<CalibrationFlow> {
  int step = 1;
  bool isMetric = true;
  double height = 170;
  double weight = 65;
  String bodyType = "Normal";
  String goal = "Muscular";

  double get bmi => weight / ((height/100)*(height/100));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(backgroundColor: AppColors.bg, elevation: 0, leading: IconButton(icon: Icon(Icons.arrow_back, color: Colors.white), onPressed: ()=>Navigator.pop(context))),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SystemTag(text: "SYSTEM CALIBRATION STEP $step/3"),
            SizedBox(height: 16),
            LinearProgressIndicator(value: step/3, backgroundColor: AppColors.cardBg, valueColor: AlwaysStoppedAnimation(AppColors.primary)),
            ),
            SizedBox(height: 24),
            if (step == 1) _buildStep1(),
            if (step == 2) _buildStep2(),
            if (step == 3) _buildStep3(),
          ],
        ),
      ),
    );
  }

  Widget _buildStep1() {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Let me calibrate your body stats, My Liege.", style: AppTheme.headingMedium),
          SizedBox(height: 24),
          Row(children: [
            ChoiceChip(label: Text("Metric"), selected: isMetric, onSelected: (v)=>setState(()=>isMetric=v), selectedColor: AppColors.primary),
            SizedBox(width: 12),
            ChoiceChip(label: Text("Imperial"), selected: !isMetric, onSelected: (v)=>setState(()=>isMetric=!v), selectedColor: AppColors.primary),
          ]),
          SizedBox(height: 24),
          SystemCard(
            child: Column(
              children: [
                _inputField("Height (cm)", height.toStringAsFixed(0), (v)=>setState(()=>height=double.tryParse(v)??height)),
                SizedBox(height: 16),
                _inputField("Weight (kg)", weight.toStringAsFixed(0), (v)=>setState(()=>weight=double.tryParse(v)??weight)),
              ],
            ),
          ),
          Spacer(),
          Row(children: [
            Expanded(child: SecondaryButton(text: "Skip for now", onTap: ()=>setState(()=>step=2))),
            SizedBox(width: 12),
            Expanded(child: GlowButton(text: "Next", onTap: ()=>setState(()=>step=2))),
          ]),
        ],
      ),
    );
  }

  Widget _buildStep2() {
    String autoDetected = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Normal" : bmi < 30 ? "Good Muscle" : bmi < 35 ? "Overweight" : "Obese";
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Which best describes your current body, My Liege?", style: AppTheme.headingMedium),
          SizedBox(height: 12),
          SystemCard(
            child: Row(
              children: [
                Icon(Icons.monitor_heart, color: AppColors.cyan),
                SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("System Detected: $autoDetected", style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w700)),
                  Text("BMI ${bmi.toStringAsFixed(1)}", style: AppTheme.bodySec),
                ]),
              ],
            ),
          ),
          SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, children: [
            "Underweight","Normal","Good Muscle","Overweight","Obese"
          ].map((t) => ChoiceChip(
            label: Text(t),
            selected: bodyType==t,
            onSelected: (v)=>setState(()=>bodyType=t),
            selectedColor: AppColors.primary,
            backgroundColor: AppColors.cardBg,
            labelStyle: TextStyle(color: bodyType==t ? Colors.white : AppColors.textSec),
          )).toList()),
          Spacer(),
          GlowButton(text: "Next", onTap: ()=>setState(()=>step=3)),
        ],
      ),
    );
  }

  Widget _buildStep3() {
    List<String> options;
    if (bodyType=="Underweight") options = ["More Muscular","Very Muscular","Bulky"];
    else if (bodyType=="Normal") options = ["Lean","Muscular","Athletic"];
    else if (bodyType=="Good Muscle") options = ["Shredded","Athletic","Bulk Beast"];
    else options = ["Lean","Fit","Muscular"];
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("What is your goal, My Liege? Choose your path to greatness.", style: AppTheme.headingMedium),
          SizedBox(height: 24),
          ...options.map((o) => Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: InkWell(
              onTap: ()=>setState(()=>goal=o),
              child: SystemCard(
                borderColor: goal==o ? AppColors.primary : AppColors.cardBorder,
                child: Row(
                  children: [
                    Icon(goal==o ? Icons.check_circle : Icons.circle_outlined, color: goal==o ? AppColors.primary : AppColors.textSec),
                    SizedBox(width: 12),
                    Text(o, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          )),
          Spacer(),
          GlowButton(text: "Continue", onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (_) => SystemAccessScreen(
              hunterName: widget.hunterName,
              height: height,
              weight: weight,
              bodyType: bodyType,
              goal: goal,
            )));
          }),
        ],
      ),
    );
  }

  Widget _inputField(String label, String value, Function(String) onChanged) {
    return TextField(
      controller: TextEditingController(text: value),
      onChanged: onChanged,
      keyboardType: TextInputType.number,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(labelText: label, labelStyle: TextStyle(color: AppColors.textSec), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
    );
  }
}

class SecondaryButton extends StatelessWidget {
  final String text; final VoidCallback onTap;
  SecondaryButton({required this.text, required this.onTap});
  @override Widget build(BuildContext context) => TextButton(onPressed: onTap, child: Text(text, style: TextStyle(color: AppColors.textSec)));
}
