import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/mascot_apex.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/system_tag.dart';
import 'name_input_screen.dart';
import 'package:google_fonts/google_fonts.dart';

class WarriorInitScreen extends StatefulWidget {
  @override State<WarriorInitScreen> createState() => _WarriorInitScreenState();
}

class _WarriorInitScreenState extends State<WarriorInitScreen> {
  int step = 0;
  final steps = [
    {"title": "Congratulations on becoming a player!\nInitializing System...", "showMascot": false},
    {"title": "SYSTEM that will keep track of you,\nhelp you grow and achieve greatness!", "showMascot": false},
    {"title": "THE SYSTEM HAS CHOSEN YOU", "showMascot": false},
    {"title": "APEX PLAYER", "showMascot": true},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              SizedBox(height: 40),
              SystemTag(text: "SYSTEM"),
              Spacer(),
              if (step < 3)
                Text(steps[step]["title"] as String, style: AppTheme.headingLarge, textAlign: TextAlign.center),
              if (step == 3) ...[
                Text("APEX", style: AppTheme.orbitronBig),
                SizedBox(height: 4),
                Text("PLAYER", style: GoogleFonts.spaceGrotesk(color: AppColors.textSec, letterSpacing: 12, fontSize: 18, fontWeight: FontWeight.w600)),
                SizedBox(height: 32),
                MascotApex(size: 140, speech: "It's my greatest honor to serve you My Liege!"),
                SizedBox(height: 24),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(color: AppColors.cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.auto_awesome, color: AppColors.cyan, size: 16),
                    SizedBox(width: 8),
                    Text("Intelligence 12", style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ],
              Spacer(),
              GlowButton(
                text: "Amazing! Let's Go!",
                onTap: () {
                  if (step < 3) setState(()=>step++);
                  else Navigator.push(context, MaterialPageRoute(builder: (_) => NameInputScreen()));
                },
              ),
              SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}
