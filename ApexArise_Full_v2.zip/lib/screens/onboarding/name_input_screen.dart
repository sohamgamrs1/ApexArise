import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/mascot_apex.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/system_card.dart';
import '../calibration/calibration_flow.dart';

class NameInputScreen extends StatefulWidget {
  @override State<NameInputScreen> createState() => _NameInputScreenState();
}

class _NameInputScreenState extends State<NameInputScreen> {
  final controller = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              SizedBox(height: 20),
              SystemTag(),
              SizedBox(height: 40),
              MascotApex(size: 110, speech: "My Liege! Provide me a name suitable to serve you."),
              Spacer(),
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Hunter Name", style: AppTheme.bodySec),
                    SizedBox(height: 12),
                    TextField(
                      controller: controller,
                      style: TextStyle(color: Colors.white, fontSize: 18),
                      decoration: InputDecoration(
                        hintText: "Heroo",
                        hintStyle: TextStyle(color: AppColors.textSec),
                        filled: true,
                        fillColor: AppColors.bg,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.cardBorder)),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.cardBorder)),
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: AppColors.primary)),
                      ),
                    ),
                  ],
                ),
              ),
              Spacer(),
              GlowButton(
                text: "Done",
                onTap: () {
                  final name = controller.text.trim().isEmpty ? "Heroo" : controller.text.trim();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CalibrationFlow(hunterName: name)));
                },
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
