import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../services/usage_service.dart';
import '../threat/threat_detection_screen.dart';

class SystemAccessScreen extends StatefulWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  SystemAccessScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal});
  @override State<SystemAccessScreen> createState() => _SystemAccessScreenState();
}

class _SystemAccessScreenState extends State<SystemAccessScreen> {
  bool checking = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "SYSTEM ACCESS"),
              SizedBox(height: 24),
              Text("System needs permission to show and control your distractions. Are you ready to control your distractions?", style: AppTheme.headingMedium),
              SizedBox(height: 24),
              SystemCard(child: _featureRow(Icons.bar_chart, "Screen Time Report", "See which apps are stealing hours")),
              SizedBox(height: 12),
              SystemCard(child: _featureRow(Icons.warning_amber_rounded, "Boss App Detected", "Your #1 distraction gets flagged as the Final Boss to defeat", color: AppColors.danger)),
              SizedBox(height: 12),
              SystemCard(child: _featureRow(Icons.auto_awesome, "Smart Plan Built", "Training targets calibrated to your real usage habits.")),
              SizedBox(height: 16),
              SystemCard(
                borderColor: AppColors.cardBorder,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Preview", style: AppTheme.bodySec),
                    SizedBox(height: 8),
                    _previewRow("Instagram", "4h 12m", AppColors.danger),
                    _previewRow("YouTube", "5h 08m", AppColors.primary),
                    _previewRow("WhatsApp", "2h 01m", AppColors.success),
                  ],
                ),
              ),
              Spacer(),
              Row(
                children: [
                  Expanded(child: GlowButton(text: checking ? "Checking..." : "Grant", onTap: () async {
                    setState(()=>checking=true);
                    await UsageService.openUsageSettings();
                    // Poll permission
                    for(int i=0;i<20;i++){
                      await Future.delayed(Duration(seconds: 1));
                      if (await UsageService.hasPermission()) {
                        if (mounted) {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => ThreatDetectionScreen(
                            hunterName: widget.hunterName,
                            height: widget.height,
                            weight: widget.weight,
                            bodyType: widget.bodyType,
                            goal: widget.goal,
                          )));
                        }
                        return;
                      }
                    }
                    setState(()=>checking=false);
                  })),
                  SizedBox(width: 12),
                  Expanded(child: TextButton(onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (_) => ThreatDetectionScreen(
                      hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal,
                    )));
                  }, child: Text("No, Thanks", style: TextStyle(color: AppColors.textSec)))),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _featureRow(IconData icon, String title, String desc, {Color? color}) {
    return Row(
      children: [
        Icon(icon, color: color ?? AppColors.primary),
        SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
          Text(desc, style: AppTheme.bodySec.copyWith(fontSize: 12)),
        ])),
      ],
    );
  }

  Widget _previewRow(String name, String time, Color color) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(width: 8,height: 8,decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          SizedBox(width: 8),
          Text(name, style: TextStyle(color: Colors.white)),
          Spacer(),
          Text(time, style: TextStyle(color: AppColors.textSec)),
        ],
      ),
    );
  }
}
