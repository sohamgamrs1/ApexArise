import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/breathing_orb.dart';
import '../commitment/commitment_screen.dart';

class BreathingQuestScreen extends StatefulWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  final Map<String,int> stats;
  BreathingQuestScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal, required this.stats});
  @override State<BreathingQuestScreen> createState() => _BreathingQuestScreenState();
}

class _BreathingQuestScreenState extends State<BreathingQuestScreen> {
  bool completed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            children: [
              SystemTag(text: "INSTANT QUEST"),
              SizedBox(height: 20),
              SystemCard(
                child: Column(
                  children: [
                    Text("Instant Quest - Take one deep breath. Follow the breath guide below, then tap ✓", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    SizedBox(height: 12),
                    Row(children: [
                      _rewardChip("+10 XP"),
                      SizedBox(width: 8),
                      _rewardChip("Calm Boost"),
                      SizedBox(width: 8),
                      _rewardChip("First Win"),
                    ]),
                  ],
                ),
              ),
              Spacer(),
              BreathingOrb(onCycleComplete: ()=>setState(()=>completed=true)),
              Spacer(),
              GlowButton(text: completed ? "Claim +10 XP" : "Complete the Quest First", onTap: completed ? (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => CommitmentScreen(
                  hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal, stats: widget.stats,
                )));
              } : (){}, enabled: completed),
              SizedBox(height: 12),
              TextButton(onPressed: (){ setState(()=>completed=false); }, child: Text("Guide My Breath Again", style: TextStyle(color: AppColors.textSec))),
              SizedBox(height: 8),
              Text("Tiny action... visible reward... momentum... identity change.", style: TextStyle(color: AppColors.textSec, fontSize: 10), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }

  Widget _rewardChip(String t) => Container(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.bg, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.primary.withOpacity(0.4))), child: Text(t, style: TextStyle(color: AppColors.cyan, fontSize: 11)));
}
