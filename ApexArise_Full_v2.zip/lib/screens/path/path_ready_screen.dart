import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/system_card.dart';
import '../../widgets/glow_button.dart';
import '../../widgets/mascot_apex.dart';
import '../home/home_systemx_screen.dart';

class PathReadyScreen extends StatelessWidget {
  final String hunterName;
  final Map<String,int> stats;
  PathReadyScreen({required this.hunterName, required this.stats});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "PATH SYNTHESIS"),
              SizedBox(height: 16),
              Text("Your Path Is Ready", style: AppTheme.headingLarge),
              Text("Built from your body, goal, threat, and commitment.", style: AppTheme.bodySec),
              SizedBox(height: 20),
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      MascotApex(size: 50),
                      SizedBox(width: 12),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(hunterName, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                        Text("Rank E-  Beginner", style: TextStyle(color: AppColors.cyan)),
                      ]),
                    ]),
                    SizedBox(height: 16),
                    Text("System Generated Your Path 1-5 steps timeline", style: AppTheme.bodySec),
                    SizedBox(height: 12),
                    _timelineStep("1", "Foundation Protocol", true),
                    _timelineStep("2", "Discipline Gate", false),
                    _timelineStep("3", "Focus Dungeon", false),
                    _timelineStep("4", "Boss Suppression", false),
                    _timelineStep("5", "Rank Evaluation", false),
                    SizedBox(height: 16),
                    Row(children: [
                      _statBar("Strength", 0.3),
                      SizedBox(width: 8),
                      _statBar("Discipline", 0.2),
                    ]),
                    SizedBox(height: 8),
                    Row(children: [
                      _statBar("Focus", 0.4),
                      SizedBox(width: 8),
                      _statBar("Wellbeing", 0.5),
                    ]),
                  ],
                ),
              ),
              SizedBox(height: 16),
              SystemCard(
                borderColor: AppColors.primary.withOpacity(0.4),
                child: Row(children: [
                  Icon(Icons.route, color: AppColors.primary),
                  SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text("Your Starting Route", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                    Text("Starting from Beginner: Rank E-, Primary arc Strength Arc", style: AppTheme.bodySec.copyWith(fontSize: 12)),
                  ])),
                ]),
              ),
              Spacer(),
              GlowButton(text: "Begin My Journey", onTap: (){
                Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => HomeSystemXScreen()), (r)=>false);
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _timelineStep(String num, String title, bool done) => Padding(
    padding: EdgeInsets.only(bottom: 8),
    child: Row(children: [
      Container(width: 24,height: 24,decoration: BoxDecoration(color: done ? AppColors.primary : AppColors.cardBorder, shape: BoxShape.circle), child: Center(child: Text(num, style: TextStyle(color: Colors.white, fontSize: 12)))),
      SizedBox(width: 12),
      Text(title, style: TextStyle(color: done ? Colors.white : AppColors.textSec)),
    ]),
  );

  Widget _statBar(String label, double v) => Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: TextStyle(color: AppColors.textSec, fontSize: 11)),
    SizedBox(height: 4),
    LinearProgressIndicator(value: v, backgroundColor: AppColors.bg, valueColor: AlwaysStoppedAnimation(AppColors.primary)),
  ]));
}
