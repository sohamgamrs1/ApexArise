import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/theme.dart';
import '../../widgets/system_card.dart';
import '../../widgets/system_tag.dart';
import '../../widgets/glow_button.dart';
import '../../services/usage_service.dart';
import '../smart_block/smart_block_explain_screen.dart';

class ThreatDetectionScreen extends StatefulWidget {
  final String hunterName;
  final double height, weight;
  final String bodyType, goal;
  ThreatDetectionScreen({required this.hunterName, required this.height, required this.weight, required this.bodyType, required this.goal});
  @override State<ThreatDetectionScreen> createState() => _ThreatDetectionScreenState();
}

class _ThreatDetectionScreenState extends State<ThreatDetectionScreen> {
  Map<String,int> stats = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await UsageService.getWeeklyStats();
    setState((){ stats=s; loading=false; });
  }

  @override
  Widget build(BuildContext context) {
    final totalWeekly = UsageService.calculateWeeklyTotal(stats);
    final dailyAvg = UsageService.dailyAvg(stats);
    final yearlyDays = UsageService.yearlyProjectionDays(stats);
    final topApp = stats.entries.isEmpty ? MapEntry("com.instagram.android", 252) : stats.entries.reduce((a,b)=>a.value>b.value? a:b);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: loading ? Center(child: CircularProgressIndicator(color: AppColors.primary)) :
        SingleChildScrollView(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SystemTag(text: "THREAT ANALYSIS"),
              SizedBox(height: 16),
              Text("Threat Detected. Your screen time reveals distractions.", style: AppTheme.headingMedium.copyWith(color: AppColors.danger)),
              SizedBox(height: 20),
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("HOURS WASTED THIS WEEK", style: AppTheme.bodySec),
                    SizedBox(height: 8),
                    Text("${(totalWeekly/60).toStringAsFixed(1)} hours", style: AppTheme.headingLarge),
                    SizedBox(height: 12),
                    SizedBox(height: 120, child: BarChart(
                      BarChartData(
                        gridData: FlGridData(show: false),
                        borderData: FlBorderData(show: false),
                        titlesData: FlTitlesData(
                          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v,meta)=>Text(["We","Th","Fr","Sa","Su","Mo","Tu"][v.toInt() %7], style: TextStyle(color: AppColors.textSec, fontSize: 10)))),
                          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        ),
                        barGroups: List.generate(7, (i) => BarChartGroupData(x: i, barRods: [BarChartRodData(toY: (20 + i*5).toDouble(), color: i==6 ? AppColors.danger : AppColors.primary, width: 12, borderRadius: BorderRadius.circular(4))])),
                      ),
                    )),
                    SizedBox(height: 12),
                    Text("At this rate you will spend ${yearlyDays.toStringAsFixed(0)} days on your phone this year alone", style: AppTheme.bodySec.copyWith(color: AppColors.danger)),
                  ],
                ),
              ),
              SizedBox(height: 16),
              Row(children: [
                Expanded(child: SystemCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text("Daily avg", style: AppTheme.bodySec), Text("${(dailyAvg/60).toStringAsFixed(1)}h", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))]))),
                SizedBox(width: 12),
                Expanded(child: SystemCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text("Weekly", style: AppTheme.bodySec), Text("${(totalWeekly/60).toStringAsFixed(0)}h ${totalWeekly%60}m", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))]))),
                SizedBox(width: 12),
                Expanded(child: SystemCard(borderColor: AppColors.danger, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text("Threat LVL", style: AppTheme.bodySec), Text("LVL ${(dailyAvg/60).clamp(1,10).round()} Boss", style: TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700))]))),
              ]),
              SizedBox(height: 16),
              SystemCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("ALL THREATS THIS WEEK ${stats.length} apps tracked", style: AppTheme.bodySec),
                    SizedBox(height: 12),
                    ...stats.entries.take(5).map((e){
                      final percent = (e.value/1440*100).clamp(0,100);
                      return Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                              Text(e.key.split('.').last, style: TextStyle(color: Colors.white)),
                              Text("${(e.value~/60)}h ${e.value%60}m • ${percent.toStringAsFixed(0)}%", style: AppTheme.bodySec),
                            ]),
                            SizedBox(height: 6),
                            LinearProgressIndicator(value: percent/100, backgroundColor: AppColors.bg, valueColor: AlwaysStoppedAnimation(AppColors.primary)),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
              SizedBox(height: 24),
              GlowButton(text: "I am ready to fight", onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => SmartBlockExplainScreen(
                  hunterName: widget.hunterName, height: widget.height, weight: widget.weight, bodyType: widget.bodyType, goal: widget.goal, stats: stats,
                )));
              }),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
